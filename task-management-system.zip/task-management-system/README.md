# Hệ Thống Quản Lý Công Việc (Task Management System)

Dự án Java Spring Boot hỗ trợ quản lý công việc, phân quyền cho người dùng và theo dõi dự án.

## Công nghệ sử dụng

- **Backend:** Java 17, Spring Boot 3.4.1
- **Database:** SQL Server
- **Tài liệu API:** Swagger UI (OpenAPI 3)
- **Công cụ:** Hibernate, Lombok, Maven

## Tính năng nổi bật

- **Quản lý đa thực thể:** CRUD cho Task, User và Project.
- **Xử lý lỗi tập trung:** Trả về thông báo lỗi định dạng JSON chuyên nghiệp (như ảnh demo bên dưới).
- **Tự động hóa tài liệu:** Tích hợp Swagger để thử nghiệm API trực tiếp.

## Hướng dẫn kiểm thử

1. Truy cập Swagger UI tại: `http://localhost:8080/swagger-ui/index.html`
2. Sử dụng các Endpoint trong `task-controller` để Thêm/Sửa/Xóa công việc.
3. Kiểm tra xử lý lỗi bằng cách DELETE một ID không tồn tại (ví dụ: ID 999).

## Hình ảnh minh họa

*Hệ thống trả về lỗi 404 khi không tìm thấy Task (Xử lý lỗi toàn cục thành công):*
![Error Handling Demo](https://lh3.googleusercontent.com/d/1Xy_ví_dụ_link_ảnh_của_bạn)

## Cấu hình Database

Trước khi chạy, hãy mở file `src/main/resources/application.properties` và chỉnh sửa:

- `spring.datasource.url`: Đường dẫn tới SQL Server của bạn.
- `spring.datasource.username`: Tên đăng nhập.
- `spring.datasource.password`: Mật khẩu.