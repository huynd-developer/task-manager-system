package org.example.taskmanagementsystem.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.example.taskmanagementsystem.entity.Task;
import org.example.taskmanagementsystem.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    @Autowired
    private TaskRepository taskRepository;

    @GetMapping("/user/{userId}")
    public List<Task> getTasksByUser(@PathVariable Long userId) {
        return taskRepository.findByAssignedToId(userId);
    }

    @PostMapping
    public Task create(@Valid @RequestBody Task task) {
        return taskRepository.save(task);
    }

    @GetMapping
    public List<Task> getAll() {
        return taskRepository.findAll();
    }

    @PutMapping("/{id}/status")
    public Task updateTaskStatus(@PathVariable Long id, @RequestParam String status) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy Task id: " + id));

        task.setStatus(status);
        return taskRepository.save(task);
    }

    @DeleteMapping("/{id}")
    public String deleteTask(@PathVariable Long id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy Task với ID: " + id));

        taskRepository.delete(task);
        return "Đã xóa thành công Task ID: " + id;
    }

    @Operation(summary = "Thống kê số lượng Task theo trạng thái")
    @GetMapping("/count")
    public String getCountByStatus(@RequestParam String status) {
        long count = taskRepository.countByStatus(status);
        return "Số lượng công việc đang ở trạng thái [" + status + "] là: " + count;
    }

    @Operation(summary = "Tìm kiếm Task theo từ khóa")
    @GetMapping("/search")
    public List<Task> searchTasks(@RequestParam String title) {
        return taskRepository.findByTitleContainingIgnoreCase(title);
    }
}
