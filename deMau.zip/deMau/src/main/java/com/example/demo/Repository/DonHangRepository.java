package com.example.demo.Repository;

import com.example.demo.Entity.DonHang;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonHangRepository extends JpaRepository<DonHang, Integer> {
}
